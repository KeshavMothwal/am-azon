# Amazon_Clone
clone of amazon site
